# Mouse Tail
A Gnome extension to draw the mouse tail on the screen

![screenshot.png](doc/screenshot.png)